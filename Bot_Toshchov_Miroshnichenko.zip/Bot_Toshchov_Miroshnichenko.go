package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"
)

type MerchItem struct {
	ID    int
	Name  string
	Price int
}

var (
	rnd = rand.New(rand.NewSource(time.Now().UnixNano()))

	cart = make(map[int]int)

	moviesByGenre = map[string][]string{
		"Комедия":    {"Третий лишний", "1+1", "Мальчишник в Вегасе", "Иван Васильевич меняет профессию"},
		"Боевик":     {"Джон Уик", "Крепкий орешек", "Безумный Макс"},
		"Фантастика": {"Интерстеллар", "Матрица", "Начало"},
		"Драма":      {"Побег из Шоушенка", "Зеленая миля", "Форрест Гамп"},
	}

	moviesByMood = map[string][]string{
		"Веселое":       {"Третий лишний", "Шоу Трумана", "День сурка"},
		"Грустное":      {"Хатико", "Достучаться до небес", "Список Шиндлера"},
		"Вдохновляющее": {"В погоне за счастьем", "Общество мертвых поэтов", "1+1"},
		"Напряженное":   {"Остров проклятых", "Семь", "Молчание ягнят"},
		"Новогоднее":    {"Ёлки", "Ёлки 2", "Ёлки 3", "Ёлки 1914", "Ёлки 5", "Ёлки 6", "Ёлки 7", "Ёлки 8", "Ёлки 9", "Ёлки 10", "Ёлки 11", "Ёлки 12", "Здравствуй, папа, Новый год!"},
	}

	musicByGenre = map[string][]string{
		"Рок":         {"Queen — Bohemian Rhapsody", "Кино — Группа крови", "AC/DC — Back in Black"},
		"Поп":         {"The Weeknd — Blinding Lights", "Michael Jackson — Billie Jean"},
		"Электроника": {"Home — Resonance", "Daft Punk — Get Lucky", "The Prodigy — Breathe"},
		"Джаз":        {"Miles Davis — So What", "Louis Armstrong — What a Wonderful World"},
	}

	musicByMood = map[string][]string{
		"Энергичное": {"Survivor — Eye of the Tiger", "Imagine Dragons — Believer"},
		"Спокойное":  {"Home — Resonance", "Norah Jones — Don't Know Why", "Ludovico Einaudi — Nuvole Bianche"},
		"Грустное":   {"Radiohead — Creep", "Coldplay — Fix You"},
		"Для работы": {"Home — Resonance", "The Glitch Mob — Animus Vox", "Lofi Beats Relax"},
		"Новогоднее": {"Новогодняя - Дискотека Авария", "Last Christmas - Wham!", "Let It Snow! Let It Snow! Let It Snow! - Frank Sinatra"},
	}

	jokes = []string{
		"Программист ставит рядом со стаканом воды пустой стакан: вдруг пить захочется, а вдруг нет.",
		"Было у отца три сына: двое умных, а третий — фронтендер.",
		"Сколько нужно джунов, чтобы поменять лампочку? Ноль, это проблема на стороне сервера.",
		"Работает — не трогай.",
		"Вчера нашел баг, исправил. Сегодня пришло еще пять новых.",
	}

	merchCatalog = []MerchItem{
		{ID: 1, Name: "Худи с гофером", Price: 3500},
		{ID: 2, Name: "Футболка Go", Price: 1500},
		{ID: 3, Name: "Термокружка", Price: 1100},
		{ID: 4, Name: "Набор стикеров", Price: 300},
		{ID: 5, Name: "Коврик для мыши", Price: 1200},
	}
)

func main() {
	defer func() {
		if r := recover(); r != nil {
			fmt.Println("Произошла ошибка в программе:", r)
		}
	}()

	reader := bufio.NewReader(os.Stdin)

	for {
		printMenu()
		choice, err := readInt(reader, 0, 6)
		if err != nil {
			fmt.Println("Неверный ввод, введите число от 0 до 6")
			continue
		}

		if choice == 0 {
			fmt.Println("Завершение работы.")
			break
		}

		switch choice {
		case 1:
			pickRecommendation(reader, "фильма по жанру", moviesByGenre)
		case 2:
			pickRecommendation(reader, "фильма по настроению", moviesByMood)
		case 3:
			pickRecommendation(reader, "музыки по жанру", musicByGenre)
		case 4:
			pickRecommendation(reader, "музыки по настроению", musicByMood)
		case 5:
			showJoke()
			waitForEnter(reader)
		case 6:
			catalogMenu(reader)
		}
	}
}

func printMenu() {
	fmt.Println("\nГлавное меню:")
	fmt.Println("1. Фильм по жанру")
	fmt.Println("2. Фильм по настроению")
	fmt.Println("3. Музыка по жанру")
	fmt.Println("4. Музыка по настроению")
	fmt.Println("5. Анекдот")
	fmt.Println("6. Каталог мерча")
	fmt.Println("0. Выход")
	fmt.Print("Выберите пункт: ")
}

func pickRecommendation(reader *bufio.Reader, title string, data map[string][]string) {
	keys := make([]string, 0, len(data))
	for k := range data {
		keys = append(keys, k)
	}

	fmt.Printf("\nВыбор %s:\n", title)
	for i, k := range keys {
		fmt.Printf("%d. %s\n", i+1, k)
	}
	fmt.Println("0. Назад")
	fmt.Print("Номер: ")

	choice, err := readInt(reader, 0, len(keys))
	if err != nil || choice == 0 {
		return
	}

	category := keys[choice-1]
	list := data[category]
	result := list[rnd.Intn(len(list))]

	fmt.Printf("\nСоветуем: %s\n", result)
	waitForEnter(reader)
}

func showJoke() {
	fmt.Println("\nАнекдот:")
	fmt.Println(jokes[rnd.Intn(len(jokes))])
}

func printMerch() {
	fmt.Println("\nКаталог товаров:")
	for _, item := range merchCatalog {
		fmt.Printf("ID: %d | %-25s | %d руб.\n", item.ID, item.Name, item.Price)
	}
}

func catalogMenu(reader *bufio.Reader) {
	for {
		printMerch()

		fmt.Println("\nДействия:")
		fmt.Println("1. Перейти в корзину")
		fmt.Println("2. Выход в главное меню")
		fmt.Print("Выберите действие (1-2): ")

		choice, err := readInt(reader, 1, 2)
		if err != nil {
			fmt.Println("Неверный ввод, выберите 1 или 2.")
			continue
		}

		if choice == 1 {
			cartMenu(reader)
		} else if choice == 2 {
			return
		}
	}
}


func printCart() {
	if len(cart) == 0 {
		fmt.Println("\n[Корзина пуста]")
		return
	}

	fmt.Println("\nВаша корзина:")
	total := 0
	for id, count := range cart {
		item := findMerch(id)
		if item != nil {
			subtotal := item.Price * count
			total += subtotal
			fmt.Printf("- ID: %d | %s (x%d) — %d руб.\n", item.ID, item.Name, count, subtotal)
		}
	}
	fmt.Printf("Общая стоимость: %d руб.\n", total)
}
func cartMenu(reader *bufio.Reader) {
	for {
		printCart()

		fmt.Println("\nУправление корзиной:")
		fmt.Println("1. Добавить товар")
		fmt.Println("2. Удалить товар")
		fmt.Println("3. Оплатить / Оформить заказ")
		fmt.Println("4. Очистить корзину")
		fmt.Println("0. Назад к каталогу")
		fmt.Print("Выберите действие: ")

		action, err := readInt(reader, 0, 4)
		if err != nil {
			fmt.Println("Неверный ввод.")
			continue
		}

		switch action {
		case 0:
			return
		case 1:
			addToCart(reader)
		case 2:
			removeFromCart(reader)
		case 3:
			if len(cart) == 0 {
				fmt.Println("Корзина пуста. Нечего оформлять.")
				waitForEnter(reader)
				continue
			}
			checkout(reader)
		case 4:
			cart = make(map[int]int)
			fmt.Println("Корзина полностью очищена.")
			waitForEnter(reader)
		}
	}
}

func addToCart(reader *bufio.Reader) {
	fmt.Print("\nВведите ID товара (0 - отмена): ")
	id, err := readInt(reader, 0, len(merchCatalog))
	if err != nil || id == 0 {
		return
	}

	item := findMerch(id)
	if item == nil {
		fmt.Println("Товар с таким ID не найден.")
		waitForEnter(reader)
		return
	}

	fmt.Printf("Количество для «%s» (1-10): ", item.Name)
	count, err := readInt(reader, 1, 10)
	if err != nil {
		fmt.Println("Некорректное количество.")
		waitForEnter(reader)
		return
	}

	cart[id] += count
	fmt.Printf("Добавлено: %s (%d шт.)\n", item.Name, count)
	waitForEnter(reader)
}

func removeFromCart(reader *bufio.Reader) {
	if len(cart) == 0 {
		fmt.Println("В корзине пока нет товаров для удаления.")
		waitForEnter(reader)
		return
	}

	fmt.Print("\nВведите ID товара для удаления (0 - отмена): ")
	id, err := readInt(reader, 0, 100)
	if err != nil || id == 0 {
		return
	}

	currentCount, exists := cart[id]
	if !exists {
		fmt.Println("Этого товара нет в корзине.")
		waitForEnter(reader)
		return
	}

	item := findMerch(id)
	fmt.Printf("В корзине сейчас %d шт. Сколько убрать? (введите %d или больше для полного удаления): ", currentCount, currentCount)
	countToRemove, err := readInt(reader, 1, 100)
	if err != nil {
		fmt.Println("Неверное количество.")
		waitForEnter(reader)
		return
	}

	if countToRemove >= currentCount {
		delete(cart, id)
		fmt.Printf("Товар «%s» полностью удален из корзины.\n", item.Name)
	} else {
		cart[id] -= countToRemove
		fmt.Printf("Убрано %d шт. Осталось: %d шт.\n", countToRemove, cart[id])
	}

	waitForEnter(reader)
}

func checkout(reader *bufio.Reader) {fmt.Println("\n--- Оформление заказа и оплата ---")
	fmt.Print("Имя получателя: ")
	name, _ := readLine(reader)
	if name == "" {
		name = "Покупатель"
	}

	fmt.Print("Город/адрес доставки: ")
	address, _ := readLine(reader)
	if address == "" {
		address = "Самовывоз"
	}

	total := 0
	fmt.Println("\nЗаказ успешно принят и оплачен!")
	fmt.Println("Клиент:", name)
	fmt.Println("Адрес доставки:", address)
	fmt.Println("Купленные товары:")

	for id, count := range cart {
		item := findMerch(id)
		if item != nil {
			subtotal := item.Price * count
			total += subtotal
			fmt.Printf("- %s x%d — %d руб.\n", item.Name, count, subtotal)
		}
	}

	fmt.Printf("Итого списано: %d руб.\n", total)
	fmt.Println("(Интерфейс покупки отработал, эмуляция платежа завершена успешно)")

	cart = make(map[int]int)
	waitForEnter(reader)
}

func findMerch(id int) *MerchItem {
	for _, item := range merchCatalog {
		if item.ID == id {
			return &item
		}
	}
	return nil
}

func waitForEnter(reader *bufio.Reader) {
	fmt.Print("\n[Нажмите Enter, чтобы продолжить...]")
	reader.ReadString('\n')
}

func readInt(reader *bufio.Reader, min, max int) (int, error) {
	input, err := readLine(reader)
	if err != nil {
		return 0, err
	}

	val, err := strconv.Atoi(input)
	if err != nil {
		return 0, err
	}

	if val < min || val > max {
		return 0, fmt.Errorf("out of range")
	}

	return val, nil
}

func readLine(reader *bufio.Reader) (string, error) {
	str, err := reader.ReadString('\n')
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(str), nil
}